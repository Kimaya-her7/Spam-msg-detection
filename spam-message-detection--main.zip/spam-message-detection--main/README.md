Spam Message Detection Project <br>
This project focuses on building a machine learning model to detect spam messages. The model classifies messages as either "spam" or "ham" (not spam) using natural language processing (NLP) techniques.
